## AM - version december 24 2021
# options(andromedaTempFolder = "...")

# install TreatmentPatterns package
devtools::install_github("mi-erasmusmc/TreatmentPatterns")

# fill in all 'todo'
databaseName <- 'todo'
folder <- file.path('todo', 'treatmentpatterns_code_24dec')

# run code below
library(TreatmentPatterns)
dataSettings <- createDataSettings(OMOP_CDM = TRUE,
                                   connectionDetails = DatabaseConnector::createConnectionDetails(dbms = 'todo',
                                                                                                  server = 'todo',
                                                                                                  user = 'todo',
                                                                                                  password = 'todo',
                                                                                                  port = 'todo'),
                                   cdmDatabaseSchema = 'todo',
                                   cohortDatabaseSchema = 'todo',
                                   cohortTable = "treatmentpatterns_covid")

cohortSettings <-
  createCohortSettings(
    cohortsToCreate_location = file.path(folder, "cohorts_to_create.csv"),
    loadCohorts = FALSE,
    cohortsFolder = file.path(folder, "cohorts"))

characterizationSettings <-
  createCharacterizationSettings(returnCovariates = "all")

pathwaySettings_list <- list()

mainCohorts <- c(3,6,7,17:22) # TE VTE narrow, TE MI ISC stroke, TTS any (main / background / after vaccin cohort)
for (cohortId in mainCohorts) {
  
  settings <- addPathwaySettings(studyName = paste0(targetCohorts$cohortName[targetCohorts$cohortId == cohortId],"_main"),
                                 targetCohortId = cohortId,
                                 eventCohortIds = c(100:123),
                                 periodPriorToIndex = 0,
                                 minEraDuration = 1,
                                 eraCollapseSize = 7,
                                 combinationWindow = 7, 
                                 minPostCombinationDuration = 1,
                                 filterTreatments = "All",
                                 maxPathLength = 5, 
                                 minCellCount = 5,
                                 minCellMethod = "Adjust",
                                 groupCombinations = 5,
                                 addNoPaths = FALSE)
  
  pathwaySettings_list <- append(pathwaySettings_list, list(settings))
}

targetCohorts <- cohortSettings$cohortsToCreate[cohortSettings$cohortsToCreate$cohortType == "target",]

for (cohortId in targetCohorts$cohortId) {
  
  settings <- addPathwaySettings(studyName = paste0(targetCohorts$cohortName[targetCohorts$cohortId == cohortId], "_sa"),
                                 targetCohortId = cohortId,
                                 eventCohortIds = c(100:123),
                                 periodPriorToIndex = 0,
                                 minEraDuration = 0,
                                 eraCollapseSize = 7,
                                 combinationWindow = 1, 
                                 minPostCombinationDuration = 1,
                                 filterTreatments = "All",
                                 maxPathLength = 5, 
                                 minCellCount = 5,
                                 minCellMethod = "Adjust",
                                 groupCombinations = 5,
                                 addNoPaths = FALSE)
  
  pathwaySettings_list <- append(pathwaySettings_list, list(settings))
}

pathwaySettings <- createPathwaySettings(pathwaySettings_list = pathwaySettings_list)

saveSettings <- createSaveSettings(databaseName = databaseName, rootFolder = folder)

TreatmentPatterns::executeTreatmentPatterns(dataSettings = dataSettings,
                                            cohortSettings = cohortSettings,
                                            characterizationSettings = characterizationSettings,
                                            pathwaySettings = pathwaySettings,
                                            saveSettings = saveSettings)
